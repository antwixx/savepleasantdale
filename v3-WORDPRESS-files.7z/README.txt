
Installation:
1. Upload pleasantdale_theme.zip via WP Admin -> Appearance -> Themes -> Add New -> Upload Theme.
2. Activate the theme.
3. For each page in the original site, create a new Page in WP Admin and on the right-side 'Template' dropdown select the corresponding template (e.g., 'page-about' for about.html).
4. Settings -> Reading : select static home page
5. If content uses relative links/images, update paths or upload images to the Media Library and replace paths in the page templates.
6. Install Rank Math plugin and change page titles/etc

Notes & Caveats:
- Inspect each page template (page-*.php) and move repeated header/footer HTML into header.php/footer.php as needed
- CSS was appended into style.css. Check file names.
- JS files were copied to assets/js and enqueued by functions.php.

