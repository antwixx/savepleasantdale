<?php
/* Template Name: concerns */
get_header();
?>

   <header class="header">
        <nav class="nav">
            <div class="nav-container">
                <a href="/home" class="nav-logo">
                    <span class="nav-logo-text">Protect Pleasantdale</span>
                </a>
                
                <button class="nav-toggle" id="navToggle">
                    <span></span>
                    <span></span>
                    <span></span>
                </button>
                
                <ul class="nav-menu" id="navMenu">
                    <li><a href="/home" class="nav-link">Home</a></li>
                    <li><a href="/information" class="nav-link">Information</a></li>
                    <li><a href="/petitions" class="nav-link">Petitions</a></li>
                    <li><a href="/contacts" class="nav-link">Contacts</a></li>
                    <li><a href="/meetings" class="nav-link">Meetings</a></li>
                    <li><a href="/concerns" class="nav-link active">Concerns</a></li>
                    <li><a href="/flyers" class="nav-link">Flyers</a></li>
                    <li><a href="/updates" class="btn btn-primary">Updates</a></li>
                </ul>
            </div>
        </nav>
    </header>

    <main class="page-content">
        <div class="container">

            <div class="page-header">
                <h1 class="page-title">Concerns & Documentation</h1>
                <p class="page-description">
                    Documentation of concerns related to the truck stop. Each concern is documented with supporting evidence or imagery.
                </p>
            </div>


            <div class="concerns-list">

                <article id="parking-idling" class="concern-post">
                    <div class="concern-post-header">
                        <div class="meeting-header">
                            <div class="meeting-icon-wrapper">
                                <i data-lucide="truck" class="meeting-icon"></i>
                            </div>
                            <div class="meeting-title-section">
                                <h2 class="concern-post-title">Illegal Overnight Parking & Idling at Lemont Truck Stop</h2>
                            </div>
                        </div>
                        <a href="#parking-idling" class="concern-anchor-link" title="Link to this concern">
                            <i data-lucide="link" style="width: 20px; height: 20px;"></i>
                        </a>
                    </div>
                    
                    <div class="concern-post-content">
                        <p>
                            Multiple instances of commercial trucks illegally parking and idling overnight have been documented at the Gas N Wash on Route 83 in Lemont, IL. 
                            This violates local ordinances and creates noise and air pollution that affects nearby residential areas.
                        </p>
                        <p>
                            <strong>Despite repeated complaints to local authorities, the practice continues to this day</strong>. Residents have documented these 
                            violations with photographic evidence and email correspondence with village officials. Cumulatively, about 100 images were shared with officials over the span of several months (February 2025 through October 2025). If these practices are continuing despite constant complaints, why would it be any different at the proposed Lemont Road location?
                        </p>
                        <p>
                            <strong>Relevant Statute: </strong> <a href="<?php echo get_template_directory_uri(); ?>/assets/uploads/Excessive Idling, Illinois General Assembly, Statute 625 ILCS 5-11-1429.pdf" target="_blank">Excessive Idling, Illinois General Assembly, Statute 625 ILCS 5-11-1429</a>
                        </p>
						<p>
						Download all ~100 images spanning from Feb 2025 through Oct 2025: <a href="<?php echo get_template_directory_uri(); ?>/assets/uploads/TruckIdling2025.zip" target="_blank" class="btn btn-small"> Download .ZIP File </a>
						</p>
                    </div>
                    
                    <div class="concern-images">

                        <div class="concern-image-item">
                            <a href="<?php echo get_template_directory_uri(); ?>/assets/images/10-01-25, Timestamp 435a.m..jpg" target="_blank">
							<img src="<?php echo get_template_directory_uri(); ?>/assets/images/10-01-25, Timestamp 435a.m..jpg" alt="Truck idling overnight">
                            <div class="concern-image-caption">October 1 at 4:35 AM</div></a>
                        </div>
                        <div class="concern-image-item">
                            <a href="<?php echo get_template_directory_uri(); ?>/assets/images/10-01-25, Timestamp 627a.m..jpg" target="_blank">
							<img src="<?php echo get_template_directory_uri(); ?>/assets/images/10-01-25, Timestamp 627a.m..jpg" alt="Truck idling overnight">
                            <div class="concern-image-caption">October 1 at 6:27 AM</div></a>
                        </div>
                        <div class="concern-image-item">
                            <a href="<?php echo get_template_directory_uri(); ?>/assets/images/3-6-25, Timestamp 607a.m..jpg" target="_blank">
							<img src="<?php echo get_template_directory_uri(); ?>/assets/images/3-6-25, Timestamp 607a.m..jpg" alt="Truck idling overnight">
                            <div class="concern-image-caption">March 6 at 6:07 AM</div></a>
                        </div>
						<div class="concern-image-item">
                            <a href="<?php echo get_template_directory_uri(); ?>/assets/images/3-6-25, Timestamp 725 a.m..jpg" target="_blank">
							<img src="<?php echo get_template_directory_uri(); ?>/assets/images/3-6-25, Timestamp 725 a.m..jpg" alt="Truck idling overnight">
                            <div class="concern-image-caption">March 6 at 7:25 AM</div></a>
                        </div>
                        <div class="concern-image-item">
                            <a href="<?php echo get_template_directory_uri(); ?>/assets/images/3-6-25, Timestamp 650 p.m..jpg" target="_blank">
							<img src="<?php echo get_template_directory_uri(); ?>/assets/images/3-6-25, Timestamp 650 p.m..jpg" alt="Truck idling overnight">
                            <div class="concern-image-caption">March 6 at 6:50 PM</div></a>
                        </div>
                        <div class="concern-image-item">
                            <a href="<?php echo get_template_directory_uri(); ?>/assets/images/3-7-25, Timestamp 446 a.m..jpg" target="_blank">
							<img src="<?php echo get_template_directory_uri(); ?>/assets/images/3-7-25, Timestamp 446 a.m..jpg" alt="Truck idling overnight">
                            <div class="concern-image-caption">March 7 at 4:46 AM</div></a>
                        </div>
						<div class="concern-image-item">
                            <a href="<?php echo get_template_directory_uri(); ?>/assets/images/3-7-25, Timestamp 630 a.m..jpg" target="_blank">
							<img src="<?php echo get_template_directory_uri(); ?>/assets/images/3-7-25, Timestamp 630 a.m..jpg" alt="Truck idling overnight">
                            <div class="concern-image-caption">March 7 at 6:30 AM</div></a>
                        </div>
                        <div class="concern-image-item">
                            <a href="<?php echo get_template_directory_uri(); ?>/assets/images/3-13-25, Timestamp 437 a.m..jpg" target="_blank">
							<img src="<?php echo get_template_directory_uri(); ?>/assets/images/3-13-25, Timestamp 437 a.m..jpg" alt="Truck idling overnight">
                            <div class="concern-image-caption">March 13 at 4:37 AM</div></a>
                        </div>
                        <div class="concern-image-item">
                            <a href="<?php echo get_template_directory_uri(); ?>/assets/images/3-13-25, Timestamp 645 a.m..jpg" target="_blank">
							<img src="<?php echo get_template_directory_uri(); ?>/assets/images/3-13-25, Timestamp 645 a.m..jpg" alt="Truck idling overnight">
                            <div class="concern-image-caption">March 13 at 6:45 AM</div></a>
                        </div>
						<div class="concern-image-item">
                            <a href="<?php echo get_template_directory_uri(); ?>/assets/images/3-13-25, Timestamp 658 p.m..jpg" target="_blank">
							<img src="<?php echo get_template_directory_uri(); ?>/assets/images/3-13-25, Timestamp 658 p.m..jpg" alt="Truck idling overnight">
                            <div class="concern-image-caption">March 13 at 6:58 PM</div></a>
                        </div>
                        <div class="concern-image-item">
                            <a href="<?php echo get_template_directory_uri(); ?>/assets/images/3-14-25, Overnight_Parking & Idling.jpg" target="_blank">
							<img src="<?php echo get_template_directory_uri(); ?>/assets/images/3-14-25, Overnight_Parking & Idling.jpg" alt="Truck idling overnight">
                            <div class="concern-image-caption">March 14 at 2:30 AM</div></a>
                        </div>
                        <div class="concern-image-item">
                            <a href="<?php echo get_template_directory_uri(); ?>/assets/images/3-14-25, Timestamp 624 a.m..jpg" target="_blank">
							<img src="<?php echo get_template_directory_uri(); ?>/assets/images/3-14-25, Timestamp 624 a.m..jpg" alt="Truck idling overnight">
                            <div class="concern-image-caption">March 14 at 6:24 AM</div></a>
                        </div>
						<div class="concern-image-item">
                            <a href="<?php echo get_template_directory_uri(); ?>/assets/images/3-14-25, Timestamp 751 p.m..jpg" target="_blank">
							<img src="<?php echo get_template_directory_uri(); ?>/assets/images/3-14-25, Timestamp 751 p.m..jpg" alt="Truck idling overnight">
                            <div class="concern-image-caption">March 14 at 7:51 PM</div></a>
                        </div>
                        <div class="concern-image-item">
                            <a href="<?php echo get_template_directory_uri(); ?>/assets/images/3-15-25, Timestamp 521 a.m..jpg" target="_blank">
							<img src="<?php echo get_template_directory_uri(); ?>/assets/images/3-15-25, Timestamp 521 a.m..jpg" alt="Truck idling overnight">
                            <div class="concern-image-caption">March 15 at 5:21 AM</div></a>
                        </div>
                        <div class="concern-image-item">
                            <a href="<?php echo get_template_directory_uri(); ?>/assets/images/3-15-25, Timestamp 723 p.m..jpg" target="_blank">
							<img src="<?php echo get_template_directory_uri(); ?>/assets/images/3-15-25, Timestamp 723 p.m..jpg" alt="Truck idling overnight">
                            <div class="concern-image-caption">March 15 at 7:23 PM</div></a>
                        </div>
						
                    </div>
                </article>


                <article id="communications" class="concern-post">
                    <div class="concern-post-header">
                        <div class="meeting-header">
                            <div class="meeting-icon-wrapper">
                                <i data-lucide="mail" class="meeting-icon"></i>
                            </div>
                            <div class="meeting-title-section">
                                <h2 class="concern-post-title">Communications Regarding Route 83 Gas N Wash Violations</h2>
                            </div>
                        </div>
                        <a href="#communications" class="concern-anchor-link" title="Link to this concern">
                            <i data-lucide="link" style="width: 20px; height: 20px;"></i>
                        </a>
                    </div>
                    
                    <div class="concern-post-content">
                        <p>
                            Community members have engaged in extensive email correspondence and outreach efforts regarding the illegal idling 
                            issues at the Route 83 Gas N Wash location. While many more communications exist, these showcase repeated attempts to address ongoing violations 
                            with local officials and enforcement agencies.
                        </p>
                        <p>
                            The outreach includes formal complaints, photographic evidence submissions, and requests for enforcement action. 
                            Despite clear violations of idling ordinances, responses have been limited and <strong>the problems persist still to this day</strong>.
                        </p>
                    </div>
                    
                    <div class="concern-images">
                        <div class="concern-image-item">
                            <a href="<?php echo get_template_directory_uri(); ?>/assets/uploads/Communication with Village of Lemont 10-01-25.pdf" target="_blank">
							<img src="<?php echo get_template_directory_uri(); ?>/assets/images/email1.jpg" alt="Email correspondence">
                            <div class="concern-image-caption">Communication with Village of Lemont Ignored</div></a>
                        </div>
                        <div class="concern-image-item">
                            <a href="<?php echo get_template_directory_uri(); ?>/assets/uploads/Communication Lemont Mayor & Board of Trustee_4-28-25.pdf" target="_blank">
							<img src="<?php echo get_template_directory_uri(); ?>/assets/images/email3.jpg" alt="Email correspondence">
                            <div class="concern-image-caption">Communication with Lemont Trustee</div></a>
                        </div>
                        <div class="concern-image-item">
                            <a href="<?php echo get_template_directory_uri(); ?>/assets/uploads/Communication with Village of Lemont & GNW 1-21-25 through 2-24-25.pdf" target="_blank">
							<img src="<?php echo get_template_directory_uri(); ?>/assets/images/email2.jpg" alt="Email correspondence">
                            <div class="concern-image-caption">Communication with GNW & Village</div></a>
                        </div>
                        <div class="concern-image-item">
                            <a href="<?php echo get_template_directory_uri(); ?>/assets/uploads/Communications LaHa 3-31-25 through 9-16-25.pdf" target="_blank">
							<img src="<?php echo get_template_directory_uri(); ?>/assets/images/emaillaha.jpg" alt="Email correspondence">
                            <div class="concern-image-caption">Communication with Rep LaHa's Office</div></a>
                        </div>
                    </div>
                </article>
				
                <article id="dozer" class="concern-post">
                    <div class="concern-post-header">
                        <div class="meeting-header">
                            <div class="meeting-icon-wrapper">
                                <i data-lucide="construction" class="meeting-icon"></i>
                            </div>
                            <div class="meeting-title-section">
                                <h2 class="concern-post-title">Dangerous Construction Activity during Route 83 Gas N Wash Development</h2>
                            </div>
                        </div>
                        <a href="#dozer" class="concern-anchor-link" title="Link to this concern">
                            <i data-lucide="link" style="width: 20px; height: 20px;"></i>
                        </a>
                    </div>
                    
                    <div class="concern-post-content">
                        <p>
                            A FOIA document reveals that during the construction of the Gas N Wash facility on Route 83, a small dozer was 
                            observed driving down the active roadway. This dangerous practice posed significant safety risks to both motorists 
                            and construction workers.
                        </p>
                        <p>
                            The incident highlights concerning safety practices during the facility's construction phase and raises questions 
                            about oversight and enforcement of construction safety regulations. Such violations during construction may indicate 
                            a pattern of disregard for safety protocols that could continue during operational phases.
                        </p>
                        <p>
                            <strong>Obtained through:</strong> <a href="<?php echo get_template_directory_uri(); ?>/assets/uploads/Village Of Lemont FOIA_Construction Concerns, 8-2023.pdf" target="_blank">Freedom of Information Act (FOIA) request</a>
                        </p>
                    </div>
                    
                    <div class="concern-images">
                        <div class="concern-image-item">
                            <a href="<?php echo get_template_directory_uri(); ?>/assets/uploads/Village Of Lemont FOIA_Construction Concerns, 8-2023.pdf" target="_blank">
							<img src="<?php echo get_template_directory_uri(); ?>/assets/images/dozer.jpg" alt="Dozer on Route 83 during construction">
                            <div class="concern-image-caption">Dozer on Route 83 #1</div></a>
                        </div>
                        <div class="concern-image-item">
                            <a href="<?php echo get_template_directory_uri(); ?>/assets/uploads/Village Of Lemont FOIA_Construction Concerns, 8-2023.pdf" target="_blank">
							<img src="<?php echo get_template_directory_uri(); ?>/assets/images/dozer1.jpg" alt="Dozer on Route 83 during construction">
                            <div class="concern-image-caption">Dozer on Route 83 #2</div></a>
                        </div>
                        <div class="concern-image-item">
                            <a href="<?php echo get_template_directory_uri(); ?>/assets/uploads/Village Of Lemont FOIA_Construction Concerns, 8-2023.pdf" target="_blank">
							<img src="<?php echo get_template_directory_uri(); ?>/assets/images/dozer2.jpg" alt="Dozer on Route 83 during construction">
                            <div class="concern-image-caption">Dozer on Route 83 #3</div></a>
                        </div>
                    </div>
                </article>

                <article id="board-parking-idling" class="concern-post">
                    <div class="concern-post-header">
                        <div class="meeting-header">
                            <div class="meeting-icon-wrapper">
                                <i data-lucide="file-stack" class="meeting-icon"></i>
                            </div>
                            <div class="meeting-title-section">
                                <h2 class="concern-post-title">Lemont Board Meeting Discussion: Overnight Parking & Idling</h2>
                            </div>
                        </div>
                        <a href="#board-parking-idling" class="concern-anchor-link" title="Link to this concern">
                            <i data-lucide="link" style="width: 20px; height: 20px;"></i>
                        </a>
                    </div>
                    
                    <div class="concern-post-content">
                        <p>
                            Multiple PDF documents from Lemont Village Board meetings provide detailed discussions and documentation of ongoing 
                            problems with overnight parking and illegal idling at the Gas N Wash facility on Route 83. These official meeting 
                            records demonstrate the persistent nature of these violations and the challenges in enforcing existing ordinances.
                        </p>
                        <p>
                            The meeting documents include trustee discussions, resident complaints, enforcement action reports, and proposed 
                            solutions that have been attempted. The pattern of repeated discussions across multiple meetings underscores the 
                            difficulty in addressing these issues at the existing facility.
                        </p>
                        <p>
                            This documented history of compliance issues at the current Gas N Wash location is particularly relevant when 
                            considering approval of additional truck stop facilities in the area.
                        </p>

                    </div>
                    
                    <div class="concern-images">
                        <div class="concern-image-item">
							<a href="<?php echo get_template_directory_uri(); ?>/assets/uploads/2-17-25, Other, Overnight parking, It's not a truck stop.pdf" target="_blank">
                            <img src="<?php echo get_template_directory_uri(); ?>/assets/images/lemont-board-truck3.jpg" alt="Board meeting PDF discussing parking issues">
                            <div class="concern-image-caption">February 17, 2025</div></a>
                        </div>
                        <div class="concern-image-item">
							<a href="<?php echo get_template_directory_uri(); ?>/assets/uploads/7-22-24, Clerk's Report, O-30-24, No overnight parking or idling.pdf" target="_blank">
                            <img src="<?php echo get_template_directory_uri(); ?>/assets/images/lemont-board-truck2.jpg" alt="Board meeting PDF discussing parking issues">
                            <div class="concern-image-caption">July 22, 2024</div></a>
                        </div>
                        <div class="concern-image-item">
							<a href="<?php echo get_template_directory_uri(); ?>/assets/uploads/7-15-24, GNW Rezoning, Two hour parking, No overnight parking, Idling Concerns.pdf" target="_blank">
                            <img src="<?php echo get_template_directory_uri(); ?>/assets/images/lemont-board-truck1.jpg" alt="Board meeting PDF discussing parking issues">
                            <div class="concern-image-caption">July 15, 2024</div></a>
                        </div>
                    </div>
                </article>
				


                <article id="board-meeting" class="concern-post">
                    <div class="concern-post-header">
                        <div class="meeting-header">
                            <div class="meeting-icon-wrapper">
                                <i data-lucide="clipboard-list" class="meeting-icon"></i>
                            </div>
                            <div class="meeting-title-section">
                                <h2 class="concern-post-title">Past Lemont Board Meeting Discussions</h2>
                            </div>
                        </div>
                        <a href="#board-meeting" class="concern-anchor-link" title="Link to this concern">
                            <i data-lucide="link" style="width: 20px; height: 20px;"></i>
                        </a>
                    </div>
                    
                    <div class="concern-post-content">
                        <p>
                            Previous Lemont Village Board meetings have included important discussions regarding the existing Route 83 Gas N Wash facility. 
                            These meetings revealed ongoing community concerns about operations, compliance issues, and the impact on residential areas.
                        </p>
                        <p>
While the project has been framed as an economic opportunity, the track record from past hearings and public feedback shows a consistent pattern of risks tied to large-scale fuel stations. In past Planning and Zoning Commission meetings, Gas N Wash proposals were criticized for excessive signage requests, traffic complications at already busy intersections, and environmental concerns tied to stormwater, dust, and diesel emissions. Residents also voiced fears about groundwater safety, property value decline, and the compatibility of such developments with nearby homes.<br>
<br>
The July 2024 hearings further revealed frustration with construction impacts such as dust, noise, and debris, along with the problem of idling diesel trucks near residential areas. Families living nearby rely on clean air, safe roads, and peace of mind, and any missteps could have lasting consequences.
                        </p>
						<p>
							<strong>Watch the relevant Planning & Zoning Commission Meetings: </strong>
							<br><a href="https://lemont.granicus.com/player/clip/794" target="_blank">July 10, 2024 - Planning and Zoning Commission </a> (Timestamp: 19:30)
							<br><a href="https://lemont.granicus.com/player/clip/447" target="_blank">July 6, 2022 - Planning and Zoning Commission </a> (Timestamp: 3:44:45)
							<br><a href="https://lemont.granicus.com/player/clip/438" target="_blank">June 22, 2022 - Planning and Zoning Commission </a> (Timestamp: 1:51:40)
						</p>
                    </div>
                    
                    <div class="concern-images">
                        <div class="concern-image-item">
							<a href="<?php echo get_template_directory_uri(); ?>/assets/uploads/6-22-22, CASE 2022-06, GNW, Public Comment.pdf" target="_blank">
                            <img src="<?php echo get_template_directory_uri(); ?>/assets/images/board-meeting-2.jpg" alt="Board meeting minutes">
                            <div class="concern-image-caption">June 22, 2022 (Gas N Wash)</div></a>
                        </div>
                        <div class="concern-image-item">
							<a href="<?php echo get_template_directory_uri(); ?>/assets/uploads/7-10-24, CASE 2024-10, GNW Rezoning, Public Comment, Commission Discussion & Recommendation.pdf" target="_blank">
                            <img src="<?php echo get_template_directory_uri(); ?>/assets/images/board-meeting-1.jpg" alt="Public comment records">
                            <div class="concern-image-caption">July 10, 2024 (Gas N Wash)</div></a>
                        </div>
	                    <div class="concern-image-item">
							<a href="<?php echo get_template_directory_uri(); ?>/assets/uploads/7-06-22, CASE 2022-03_Bluff Road Fuel Center, CASE 2022-06_Continuation, GNW, Public Comment.pdf" target="_blank">
                            <img src="<?php echo get_template_directory_uri(); ?>/assets/images/board-meeting-3.jpg" alt="Public comment records">
                            <div class="concern-image-caption">July 6, 2022 (Bluff Rd)</div></a>
                        </div>
                    </div>
                </article>


                <article id="benzene" class="concern-post">
                    <div class="concern-post-header">
                        <div class="meeting-header">
                            <div class="meeting-icon-wrapper">
                                <i data-lucide="alert-triangle" class="meeting-icon"></i>
                            </div>
                            <div class="meeting-title-section">
                                <h2 class="concern-post-title">The Dangers of Benzene Exposure</h2>
                            </div>
                        </div>
                        <a href="#benzene" class="concern-anchor-link" title="Link to this concern">
                            <i data-lucide="link" style="width: 20px; height: 20px;"></i>
                        </a>
                    </div>
                    
                    <div class="concern-post-content">
                        <p>
                            Benzene is a known carcinogen commonly found in diesel exhaust and fuel vapors at truck stops. The Collins Law Firm 
                            has produced educational content explaining the serious health risks associated with benzene exposure, particularly 
                            for residential communities near diesel truck facilities.
                        </p>
                        <p>
                            <strong>Watch this important video:</strong> <a href="https://www.youtube.com/watch?v=a_I70PdyWv4" target="_blank" rel="noopener noreferrer" style="color: #d64e4e;">The Collins Law Firm - Benzene Dangers</a>
                        </p>
                        <p>
                            Long-term exposure to benzene, even at low levels, can lead to serious health issues including blood disorders and cancer. 
                            The concentration of diesel trucks at the proposed facility would significantly increase benzene exposure for nearby residents.
                        </p>
                    </div>
                    
                    <div class="concern-images">
                        <div class="concern-image-item">
                            <a href="https://www.youtube.com/watch?v=a_I70PdyWv4" target="_blank" rel="noopener noreferrer">
                                <img src="<?php echo get_template_directory_uri(); ?>/assets/images/play_icon.png" alt="Benzene dangers video">
                                <div class="concern-image-caption">Click to watch video</div>
                            </a>
                        </div>
                    </div>
                </article>


                <article id="northwestern-studies" class="concern-post">
                    <div class="concern-post-header">
                        <div class="meeting-header">
                            <div class="meeting-icon-wrapper">
                                <i data-lucide="file-bar-chart" class="meeting-icon"></i>
                            </div>
                            <div class="meeting-title-section">
                                <h2 class="concern-post-title">Northwestern University Studies on Truck Pollution</h2>
                            </div>
                        </div>
                        <a href="#northwestern-studies" class="concern-anchor-link" title="Link to this concern">
                            <i data-lucide="link" style="width: 20px; height: 20px;"></i>
                        </a>
                    </div>
                    
                    <div class="concern-post-content">
                        <p>
                            Northwestern University researchers have conducted comprehensive studies examining the health and air quality impacts of 
                            truck pollution on nearby communities. These peer-reviewed studies provide scientific evidence of the serious risks posed 
                            by concentrations of diesel truck traffic.
                        </p>
                        <p>
                            The research demonstrates measurable increases in respiratory problems, cardiovascular disease, and reduced air quality 
                            in areas exposed to high volumes of truck traffic. Children and elderly residents face particularly elevated risks.
                        </p>
                        <p>
                            These studies are directly applicable to our community's concerns about the proposed truck stop development and its 
                            potential health impacts on nearby residential areas.
                        </p>
                    </div>
                    
                    <div class="concern-images">
                        <div class="concern-image-item">
                            <a href="<?php echo get_template_directory_uri(); ?>/assets/uploads/Advanced Clean Trucks Policy Research Northwestern University 03-10-25.pdf" target="_blank">
							<img src="<?php echo get_template_directory_uri(); ?>/assets/images/Advanced-Clean-Trucks-Research.jpg" alt="Northwestern study on health impacts">
                            <div class="concern-image-caption">Assessing the air quality</div></a>
                        </div>
                        <div class="concern-image-item">
                            <a href="<?php echo get_template_directory_uri(); ?>/assets/uploads/Stricter-Truck-Pollution-Rule-Prevents-500-Deaths-Year%2003-2025.pdf" target="_blank">
							<img src="<?php echo get_template_directory_uri(); ?>/assets/images/Stricter-Truck-Pollution.jpg" alt="Northwestern study on air quality">
                            <div class="concern-image-caption">Stricter truck pollution rule</div></a>
                        </div>
                    </div>
                </article>


                <article id="tinley-park" class="concern-post">
                    <div class="concern-post-header">
                        <div class="meeting-header">
                            <div class="meeting-icon-wrapper">
                                <i data-lucide="users" class="meeting-icon"></i>
                            </div>
                            <div class="meeting-title-section">
                                <h2 class="concern-post-title">Tinley Park Mayor's Connection to Lenny's Gas N Wash</h2>
                            </div>
                        </div>
                        <a href="#tinley-park" class="concern-anchor-link" title="Link to this concern">
                            <i data-lucide="link" style="width: 20px; height: 20px;"></i>
                        </a>
                    </div>
                    
                    <div class="concern-post-content">
                        <p>
                            Investigative reporting has revealed concerning connections between current Tinley Park Mayor Michael Glotz and Lenny's Gas N Wash, 
                            which is seeking a third truck stop location. According to South Cook News, Mayor Glotz has received substantial political donations from the business and has actively advocated for their expansion plans.
                        </p>
                        <p>
                            <strong>Read the full article:</strong> <a href="https://southcooknews.com/stories/643885932-tinley-park-mayor-glotz-s-top-political-donor-lenny-s-gas-n-wash-seeks-third-truck-stop-site" target="_blank" rel="noopener noreferrer" style="color: #d64e4e;">South Cook News - Mayor Glotz and Lenny's Gas N Wash</a>
                        </p>
                        <p>
                            <strong>Watch the video:</strong> <a href="https://www.youtube.com/watch?v=zaO6wrDiyTg" target="_blank" rel="noopener noreferrer" style="color: #d64e4e;">Video: Mayor Glotz Advocacy for Gas N Wash</a>
                        </p>
                        <p>
                            These political and financial relationships raise important questions about the decision-making process surrounding 
                            truck stop approvals and the influence of special interests on community development decisions.
                        </p>
                    </div>
                    
                    <div class="concern-images">
                        <div class="concern-image-item">
                            <a href="https://southcooknews.com/stories/643885932-tinley-park-mayor-glotz-s-top-political-donor-lenny-s-gas-n-wash-seeks-third-truck-stop-site" target="_blank" rel="noopener noreferrer">
                                <img src="<?php echo get_template_directory_uri(); ?>/assets/images/tinley-park-text.jpg" alt="South Cook News article">
                                <div class="concern-image-caption">Click to read article</div>
                            </a>
                        </div>
                        <div class="concern-image-item">
                            <a href="https://www.youtube.com/watch?v=zaO6wrDiyTg" target="_blank" rel="noopener noreferrer">
                                <img src="<?php echo get_template_directory_uri(); ?>/assets/images/play_icon.png" alt="Video coverage">
                                <div class="concern-image-caption">Click to watch video</div>
                            </a>
                        </div>
                    </div>
                </article>


                <article id="lemont-gambling" class="concern-post">
                    <div class="concern-post-header">
                        <div class="meeting-header">
                            <div class="meeting-icon-wrapper">
                                <i data-lucide="bar-chart" class="meeting-icon"></i>
                            </div>
                            <div class="meeting-title-section">
                                <h2 class="concern-post-title">Lemont Video Gaming Revenue Data</h2>
                            </div>
                        </div>
                        <a href="#lemont-gambling" class="concern-anchor-link" title="Link to this concern">
                            <i data-lucide="link" style="width: 20px; height: 20px;"></i>
                        </a>
                    </div>
                    
                    <div class="concern-post-content">
                        <p>
                            <strong>2020–2024 Report:</strong> This document shows Lemont's full video gaming revenue data across multiple establishments over several years. Despite COVID-19 shutdown periods in 2020, total wagering exceeded $488 million, with net terminal income (NTI) of about $39.6 million. The state collected around $13.5 million, while Lemont itself received just under $2 million in municipal share.
                        </p>
                        <p>
                            <strong>YTD August 2025 Report:</strong> Covering January through August 2025, Lemont's video gaming generated about $92 million in wagers, with net terminal income (NTI) of roughly $8 million. From this, the state collected nearly $2.8 million and Lemont received around $408,000 in municipal share.
                        </p>
                        <p>
                            This shows 2025 is on pace to match or slightly exceed the average annual levels from the prior period, indicating steady or modestly rising gaming revenue.
                        </p>
                        <p>
                            <strong>Source: </strong><a href="https://igb.illinois.gov/video-gaming/video-reports.html" target="_blank">Illinois Gaming Board</a>
                        </p>
                    </div>
                    
                    <div class="concern-images">
                        <div class="concern-image-item">
                            <a href="<?php echo get_template_directory_uri(); ?>/assets/uploads/VGRevenueReport2020-2024.pdf" target="_blank">
							<img src="<?php echo get_template_directory_uri(); ?>/assets/images/Gambling2020-2024.jpg" alt="Lemont gaming revenue 2020-2024">
                            <div class="concern-image-caption">2020-2024 Revenue Report</div></a>
                        </div>
                        <div class="concern-image-item">
                            <a href="<?php echo get_template_directory_uri(); ?>/assets/uploads/VGRevenueReportYTDAug2025.pdf" target="_blank">
							<img src="<?php echo get_template_directory_uri(); ?>/assets/images/GamblingAug2025.jpg" alt="Lemont gaming revenue YTD 2025">
                            <div class="concern-image-caption">YTD August 2025 Report</div></a>
                        </div>
                    </div>
                </article>

            </div>
        </div>
    </main>

    <footer class="footer">
        <div class="container">
            <p class="footer-text">Disclaimer: The content on this website is provided for informational purposes only and does not constitute professional advice. We make no warranties about the accuracy, completeness, or timeliness of the information. For advice tailored to your specific situation, please consult a qualified professional.</p>
        </div>
    </footer>


<?php get_footer(); ?>
