<?php
/* Template Name: updates */
get_header();
?>

    <header class="header">
        <nav class="nav">
            <div class="nav-container">
                <a href="/home" class="nav-logo">
                    <span class="nav-logo-text">Protect Pleasantdale</span>
                </a>
                
                <button class="nav-toggle" id="navToggle">
                    <span></span>
                    <span></span>
                    <span></span>
                </button>
                
                <ul class="nav-menu" id="navMenu">
                    <li><a href="/home" class="nav-link">Home</a></li>
                    <li><a href="/information" class="nav-link">Information</a></li>
                    <li><a href="/petitions" class="nav-link">Petitions</a></li>
                    <li><a href="/contacts" class="nav-link">Contacts</a></li>
                    <li><a href="/meetings" class="nav-link">Meetings</a></li>
                    <li><a href="/concerns" class="nav-link">Concerns</a></li>
                    <li><a href="/flyers" class="nav-link">Flyers</a></li>
                    <li><a href="/updates" class="btn btn-primary">Updates</a></li>
                </ul>
            </div>
        </nav>
    </header>

    <main class="page-content">
        <div class="container">

            <div class="page-header">
                <h1 class="page-title">Community Updates</h1>
                <p class="page-description">
                    Stay informed with the latest news and developments regarding the truck stop proposal and our community action efforts.
                </p>
            </div>


            <div class="meetings-list">
				

				<div class="meeting-card">
                    <div class="meeting-header">
                        <div class="meeting-icon-wrapper">
                            <i data-lucide="alert-triangle" class="disclaimer-icon"></i>
                        </div>
                        <div class="meeting-title-section">
                            <h3 class="meeting-title">Woodridge Eyes Southern Lemont Road for Major Development</h3>
                            <p class="meeting-type">Posted 9/21/25</p>
                        </div>
                    </div>

                    <div class="meeting-description">
                        <p>Woodridge’s comprehensive plan outlines large-scale housing, retail, and mixed-use developments along Southern Lemont Road over the next decade. These projects could reshape traffic, infrastructure, and the character of nearby neighborhoods like Pleasantdale. It’s critical for residents to stay informed and speak up about how these changes may affect our community. Explore more information by viewing the PDF below or at <a href="https://woodridgecompplan.com" target="_blank">WoodridgeCompPlan.com</a></p>
                    </div>
					<div class="meeting-actions">
                        <div class="pdf-download">
                                <a href="<?php echo get_template_directory_uri(); ?>/assets/uploads/Southern-Lemont-Meeting-Presentation.pdf" target="blank" class="btn btn-small"> View PDF </a>
                    	</div> 
                    </div>
                </div>
				
				<div class="meeting-card">
                    <div class="meeting-header">
                        <div class="meeting-icon-wrapper">
                            <i data-lucide="file-text" class="meeting-icon"></i>
                        </div>
                        <div class="meeting-title-section">
                            <h3 class="meeting-title">Letter from Downers Grove Township Officials Oppose Rezoning</h3>
                            <p class="meeting-type">Posted 9/12/25</p>
                        </div>
                    </div>

                    <div class="meeting-description">
                        <p>A pair of Downers Grove Township officials have joined the opposition to rezoning houses to pave the way for a new gas station just south of Darien. In a letter, the township's supervisor, Kim Savage, and its highway commissioner, Tom Chlystek, wrote to the village of Lemont on behalf of residents of the unincorporated Pleasantdale neighborhood, with an estimated more than 300 homes. Link below.</p>
                    </div>

                    <div class="meeting-actions">
                        <div class="pdf-download">
                                <a href="<?php echo get_template_directory_uri(); ?>/assets/images/Asset-1-scaled.png" target="_blank" class="btn btn-small"> View Letter </a>
                            </div>
                        
                    </div>
                </div>
				
				<div class="meeting-card">
                    <div class="meeting-header">
                        <div class="meeting-icon-wrapper">
                            <i data-lucide="book-open" class="meeting-icon"></i>
                        </div>
                        <div class="meeting-title-section">
                            <h3 class="meeting-title">[News] Patch: Officials Oppose Darien-Area Gas Station</h3>
                            <p class="meeting-type">Posted 9/9/25</p>
                        </div>
                    </div>

                    <div class="meeting-description">
                        <p>The officials cited their concerns about the station's impacts in a letter to a nearby village. Article link below.</p>
                    </div>

                    <div class="meeting-actions">
                        <div class="pdf-download">
                                <a href="https://patch.com/illinois/darien-il/officials-oppose-darien-area-gas-station" target="_blank" class="btn btn-small"> View Article </a>
                            </div>
                        
                    </div>
                </div>
				

                <div class="meeting-card">
                    <div class="meeting-header">
                        <div class="meeting-icon-wrapper">
                            <i data-lucide="book-open" class="meeting-icon"></i>
                        </div>
                        <div class="meeting-title-section">
                            <h3 class="meeting-title">New Research Materials Available</h3>
                            <p class="meeting-type">Posted 9/1/25</p>
                        </div>
                    </div>

                    <div class="meeting-description">
                        <p>We've compiled comprehensive research on health, environmental, and safety concerns related to gas stations and truck stops. Download PDFs with citations and share with neighbors.</p>
                    </div>

                    <div class="meeting-actions">
                        <div class="pdf-download">
                                <a href="/information" class="btn btn-small"> View Research </a>
                            </div>
                        
                    </div>
                </div>
				
				<div class="meeting-card">
                    <div class="meeting-header">
                        <div class="meeting-icon-wrapper">
                            <i data-lucide="book-open" class="meeting-icon"></i>
                        </div>
                        <div class="meeting-title-section">
                            <h3 class="meeting-title">[News] Patch: Lemont Annexation May Affect Darien Area, Pave Way For Gas Station</h3>
                            <p class="meeting-type">Posted 8/12/25</p>
                        </div>
                    </div>

                    <div class="meeting-description">
                        <p>A gas station chain's request was granted. Neighbors were opposed, saying a station would hurt their area. Article link below.</p>
                    </div>

                    <div class="meeting-actions">
                        <div class="pdf-download">
                                <a href="https://patch.com/illinois/darien-il/lemont-annexation-may-affect-darien-area" target="_blank" class="btn btn-small"> View Article </a>
                            </div>
                    </div>
                </div>
				
				
				<div class="meeting-card">
                    <div class="meeting-header">
                        <div class="meeting-icon-wrapper">
                            <i data-lucide="book-open" class="meeting-icon"></i>
                        </div>
                        <div class="meeting-title-section">
                            <h3 class="meeting-title">[News] Patch: Gas Station Near Darien May Be In Works</h3>
                            <p class="meeting-type">Posted 7/8/25</p>
                        </div>
                    </div>

                    <div class="meeting-description">
                        <p>Neighbors are likely to oppose a possible chain station in their area. Article link below</p>
                    </div>

                    <div class="meeting-actions">
                        <div class="pdf-download">
                                <a href="https://patch.com/illinois/darien-il/gas-station-near-darien-may-be-works" target="_blank" class="btn btn-small"> View Article </a>
                            </div>
                        
                    </div>
                </div>
            </div>

    </main>

    <footer class="footer">
        <div class="container">
            <p class="footer-text">Disclaimer: The content on this website is provided for informational purposes only and does not constitute professional advice. We make no warranties about the accuracy, completeness, or timeliness of the information. For advice tailored to your specific situation, please consult a qualified professional.</p>
        </div>
    </footer>


<?php get_footer(); ?>
