<?php
/* Template Name: flyers */
get_header();
?>

    <header class="header">
        <nav class="nav">
            <div class="nav-container">
                <a href="/home" class="nav-logo">
                    <span class="nav-logo-text">Protect Pleasantdale</span>
                </a>
                
                <button class="nav-toggle" id="navToggle">
                    <span></span>
                    <span></span>
                    <span></span>
                </button>
                
                <ul class="nav-menu" id="navMenu">
                    <li><a href="/home" class="nav-link">Home</a></li>
                    <li><a href="/information" class="nav-link">Information</a></li>
                    <li><a href="/petitions" class="nav-link">Petitions</a></li>
                    <li><a href="/contacts" class="nav-link">Contacts</a></li>
                    <li><a href="/meetings" class="nav-link">Meetings</a></li>
                    <li><a href="/concerns" class="nav-link">Concerns</a></li>
                    <li><a href="/flyers" class="nav-link active">Flyers</a></li>
					<li><a href="/updates" class="btn btn-primary">Updates</a></li>
                </ul>
            </div>
        </nav>
    </header>

    <main class="page-content">
        <div class="container">

            <div class="page-header">
                <h1 class="page-title">Flyers & Materials</h1>
                <p class="page-description">
                    Download and print flyers to spread awareness in your neighborhood. Help inform more residents about the proposed truck stop development.
                </p>
            </div>


            <div class="legal-disclaimer">
                <div class="disclaimer-header">
                    <i data-lucide="alert-triangle" class="disclaimer-icon"></i>
                    <h2 class="disclaimer-title">Important Legal Information & Distribution Guidelines</h2>
                </div>
                
                <div class="disclaimer-content">
                    <div class="disclaimer-section">
                        <h3 class="disclaimer-subtitle">Disclaimer</h3>
                        <p class="disclaimer-text">
                            The flyers and materials provided through this website are intended for informational and community use only. By downloading, printing, or distributing these materials, you agree to use them responsibly and in compliance with all applicable local, state, and federal laws. This website and its contributors are not responsible for any fines, penalties, or legal consequences resulting from improper distribution.
                        </p>
                        <p class="disclaimer-text">
                            Any mention of legal restrictions or regulations on this site is for general informational purposes only and should not be considered legal advice. If you have questions about your specific situation, you should consult local ordinances or seek guidance from a qualified attorney.
                        </p>
                    </div>

                    <div class="guidelines-grid">
                        <div class="guideline-card restricted">
                            <div class="guideline-header">
                                <i data-lucide="x-circle" class="guideline-icon"></i>
                                <h3 class="guideline-title">What You Can't Do (Without Permission)</h3>
                            </div>
                            <ul class="guideline-list">
                                <li><strong>Public Infrastructure:</strong> Posting flyers on public streets, sidewalks, street signs, traffic signals, or trees that are managed by the Village's Public Works Department is typically not allowed. While Lemont doesn't spell out a specific posting ban, similar local governments strictly regulate such displays.</li>
                                <li><strong>Mailboxes and Newspaper Boxes:</strong> Federal law prohibits placing flyers directly in U.S. mailboxes or private newspaper stands. Under federal law (18 U.S. Code § 1725), it is illegal to place unstamped material inside a U.S. Postal Service mailbox.</li>
                                <li><strong>Parks without Approval:</strong> Posting flyers in parks without a permit may violate District ordinances.</li>
								<li><strong>Other Conditions:</strong><p><br>   &bull; You must not block pedestrian or vehicle traffic. <br>
																				&bull; You can't harass or aggressively approach people. <br>
																				&bull; You must obey reasonable time, place, and manner restrictions (e.g., no amplified sound late at night, or no blocking building entrances).</li>
                            </ul>
                        </div>

                        <div class="guideline-card allowed">
                            <div class="guideline-header">
                                <i data-lucide="check-circle" class="guideline-icon"></i>
                                <h3 class="guideline-title">Where You Can Legally Post Flyers</h3>
                            </div>
                            
                            <div class="allowed-section">
                                <h4 class="allowed-subtitle">1. Private Businesses & Community Venues</h4>
                                <p class="allowed-text">Coffee shops, restaurants, libraries, gyms, schools, community centers, salons, banks, and similar establishments. Retailer bulletin boards or customer-facing spaces.</p>
                                <p class="allowed-note"><strong>Always obtain explicit permission before placing your material.</strong></p>
                            </div>

                            <div class="allowed-section">
                                <h4 class="allowed-subtitle">2. Door-to-Door or Hand Distribution</h4>
                                <p class="allowed-text"><strong>You can:</strong> Leave flyers at the front door, porch, or doorknob (using door hangers), provided the properties don't have "No Solicitation" signs. Do not enter private property without permission.</p>
                                <p class="allowed-text">The First Amendment protects your right to distribute flyers on public sidewalks and in other traditional public forums (like public streets, plazas, and parks).</p>
                                
                                <p class="allowed-text"><strong> </strong></p>
                                <ul class="condition-list">
                                    
                                </ul>
                                
                                <p class="allowed-warning"><strong>"No Soliciting" Areas:</strong> If a property or subdivision posts a "No Soliciting" or "No Handbills" sign, entering could be trespassing.</p>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

            <!-- Flyer Gallery -->
            <div class="flyer-gallery">
                <div class="flyer-item">
                    <div class="flyer-preview">
                        <div class="flyer-mockup">
                            <div class="flyer-content">
							<img src="<?php echo get_template_directory_uri(); ?>/assets/images/QR-FLYER-PRINTcap.png"></img>
                                <!---<h3>STOP THE TRUCK STOP</h3>
                                <p>Protect Our Neighborhood</p>---!>
                                <div class="flyer-details">
                                    <!---<div class="detail-line"></div>
                                    <div class="detail-line"></div>
                                    <div class="detail-line short"></div>---!>
                                </div>
                            </div>
                        </div>
                    </div>
					
					
                    <div class="flyer-info"><br>
                        <h3 class="flyer-title">Main Support Flyer</h3>
                        <p class="flyer-description">
                            Single-page support flyer with Pleasantdale donation information and how neighbors can help.
                        </p>
                        <div class="flyer-specs">
                            <span class="spec">8.5" x 11"</span>
                            <span class="spec">Full Color</span>
                            
                        </div>
                        <div class="flyer-actions">
                            <a href="<?php echo get_template_directory_uri(); ?>/assets/images/QR-FLYER-PRINTf-1.png" target="_blank" class="btn btn-primary">Download</a>
                            
                        </div>
                    </div>
					
					
                </div>
				
                <div class="flyer-item">
                    <div class="flyer-preview">
                        <div class="flyer-mockup">
                            <div class="flyer-content">
							<img src="<?php echo get_template_directory_uri(); ?>/assets/images/CaptureYard.jpg"></img>
                                <!---<h3>STOP THE TRUCK STOP</h3>
                                <p>Protect Our Neighborhood</p>---!>
                                <div class="flyer-details">
                                    <!---<div class="detail-line"></div>
                                    <div class="detail-line"></div>
                                    <div class="detail-line short"></div>---!>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="flyer-info"><br>
                        <h3 class="flyer-title">Yard Support Sign</h3>
                        <p class="flyer-description">
                            Yard sign design for request. Show visible opposition throughout the neighborhood.
                        </p>
                        <div class="flyer-specs">
                        
                            <span class="spec">Full Color</span>
                            <span class="spec">Yard Sign</span>
                        </div>
                        <div class="flyer-actions">
                            <a href="/contacts" target="_blank" class="btn btn-primary">Contact Us</a>
                            
                        </div>
                    </div>
                </div>
				
				
				
                <div class="flyer-item">
                    <div class="flyer-preview">
                        <div class="flyer-mockup">
                            <div class="flyer-content">
							<img src="<?php echo get_template_directory_uri(); ?>/assets/images/NOGASsmall.jpg"></img>
                                <!---<h3>STOP THE TRUCK STOP</h3>
                                <p>Protect Our Neighborhood</p>---!>
                                <div class="flyer-details">
                                    <!---<div class="detail-line"></div>
                                    <div class="detail-line"></div>
                                    <div class="detail-line short"></div>---!>
                                </div>
                            </div>
                        </div>
                    </div>
					
					
                    <div class="flyer-info"><br>
                        <h3 class="flyer-title">Opposition Flyer</h3>
                        <p class="flyer-description">
                            Single-page opposition flyer stating "No Gas Station in our Backyard" with the link to the website.
                        </p>
                        <div class="flyer-specs">
                            <span class="spec">8.5" x 11"</span>
                            <span class="spec">Full Color</span>
                            
                        </div>
                        <div class="flyer-actions">
                            <a href="<?php echo get_template_directory_uri(); ?>/assets/uploads/NOGASLEMONTSIGN-resize.pdf" target="_blank" class="btn btn-primary">Download</a>
                            
                        </div>
                    </div>
					
					
                </div>
				
                <div class="flyer-item">
                    <div class="flyer-preview">
                        <div class="flyer-mockup">
                            <div class="flyer-content">
							<img src="<?php echo get_template_directory_uri(); ?>/assets/images/yardsignsmall.jpg"></img>
                                <!---<h3>STOP THE TRUCK STOP</h3>
                                <p>Protect Our Neighborhood</p>---!>
                                <div class="flyer-details">
                                    <!---<div class="detail-line"></div>
                                    <div class="detail-line"></div>
                                    <div class="detail-line short"></div>---!>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="flyer-info"><br>
                        <h3 class="flyer-title">Opposition Sign</h3>
                        <p class="flyer-description">
                            Opposition sign for print. Display to show visible opposition wherever possible.
                        </p>
                        <div class="flyer-specs">
                        
                            <span class="spec">24" x 18"</span>
                            <span class="spec">Full Color</span>
                        </div>
                        <div class="flyer-actions">
                            <a href="<?php echo get_template_directory_uri(); ?>/assets/uploads/NOGASLEMONTSIGN-resize.pdf" target="_blank" class="btn btn-primary">Download</a>
                            
                        </div>
                    </div>
                </div>
				
				
            </div>



            <div class="distribution-section">
                <h2 class="distribution-title">Distribution Strategy</h2>
                <div class="distribution-grid">
                    <div class="distribution-method">
                        <div class="method-icon-wrapper">
                            <i data-lucide="home" class="method-icon"></i>
                        </div>
                        <h3 class="method-title">Door-to-Door</h3>
                        <p class="method-description">
                            Visit neighbors personally. This is the most effective way to ensure people receive and read the information.
                        </p>
                        <ul class="method-tips">
                            <li>Best times: Evenings and weekends</li>
                            <li>Be prepared to answer questions</li>
                            <li>Leave door hangers if no one's home</li>
                        </ul>
                    </div>

                    <div class="distribution-method">
                        <div class="method-icon-wrapper">
                            <i data-lucide="users" class="method-icon"></i>
                        </div>
                        <h3 class="method-title">Community Events</h3>
                        <p class="method-description">
                            Set up information tables at local markets, community events and shows, and neighborhood gatherings.
                        </p>
                        <ul class="method-tips">
                            <li>Bring clipboards for petition signatures</li>
                            <li>Have multiple flyer types available</li>
                            <li>Engage people in conversation</li>
                        </ul>
                    </div>

                    <div class="distribution-method">
                        <div class="method-icon-wrapper">
                            <i data-lucide="map-pin" class="method-icon"></i>
                        </div>
                        <h3 class="method-title">Strategic Locations</h3>
                        <p class="method-description">
                            Post flyers (with permission) at community centers, libraries, coffee shops, and other high-traffic areas.
                        </p>
                        <ul class="method-tips">
                            <li>Always ask permission first</li>
                            <li>Use community bulletin boards</li>
                            <li>Check and refresh regularly</li>
                        </ul>
                    </div>
                </div>
            </div>


            <div class="volunteer-section">
                <div class="volunteer-content">
                    <h2 class="volunteer-title">Join the Distribution Team</h2>
                    <p class="volunteer-description">
                        Help us reach every household in the affected area. We're coordinating volunteers to ensure comprehensive neighborhood coverage.
                    </p>
                    <div class="volunteer-stats">
                        <div class="stat">
                            <span class="stat-number">12+</span>
                            <span class="stat-label">Active Volunteers</span>
                        </div>
                        <div class="stat">
                            <span class="stat-number">847+</span>
                            <span class="stat-label">Households Reached</span>
                        </div>
                        <div class="stat">
                            <span class="stat-number">2,100+</span>
                            <span class="stat-label">Flyers Distributed</span>
                        </div>
                    </div>
                    <div class="volunteer-actions">
                        <a href="/meetings" class="btn btn-outline">Coordinate with Neighbors</a>
                    </div>
                </div>
            </div>
        </div>
    </main>

    <footer class="footer">
        <div class="container">
            <p class="footer-text">Disclaimer: The content on this website is provided for informational purposes only and does not constitute professional advice. We make no warranties about the accuracy, completeness, or timeliness of the information. For advice tailored to your specific situation, please consult a qualified professional.</p>
        </div>
    </footer>


<?php get_footer(); ?>
