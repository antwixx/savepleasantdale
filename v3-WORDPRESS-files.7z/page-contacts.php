<?php
/* Template Name: contacts */
get_header();
?>

    <header class="header">
        <nav class="nav">
            <div class="nav-container">
                <a href="/home" class="nav-logo">
                    <span class="nav-logo-text">Protect Pleasantdale</span>
                </a>
                
                <button class="nav-toggle" id="navToggle">
                    <span></span>
                    <span></span>
                    <span></span>
                </button>
                
                <ul class="nav-menu" id="navMenu">
                    <li><a href="/home" class="nav-link">Home</a></li>
                    <li><a href="/information" class="nav-link">Information</a></li>
                    <li><a href="/petitions" class="nav-link">Petitions</a></li>
                    <li><a href="/contacts" class="nav-link active">Contacts</a></li>
                    <li><a href="/meetings" class="nav-link">Meetings</a></li>
                    <li><a href="/concerns" class="nav-link">Concerns</a></li>
                    <li><a href="/flyers" class="nav-link">Flyers</a></li>
                    <li><a href="/updates" class="btn btn-primary">Updates</a></li>
                </ul>
            </div>
        </nav>
    </header>

    <main class="page-content">
        <div class="container">

            <div class="page-header">
                <h1 class="page-title">Contact Officials and Organizations</h1>
                <p class="page-description">
                    Reach out to local officials and Organizations to make your voice heard. Every contact helps demonstrate community opposition to the proposed truck stop.
                </p>
            </div>


            <div class="contacts-section">
			
			
			    <h2 class="contacts-section-title">Contact Pleasantdale</h2>
                <div class="contact-list">
                    <div class="contact-list-item">
                        <div class="contact-name">Pleasantdale Voluntary Civic Association</div>
                        <div class="contact-email">
                            <i data-lucide="mail" class="contact-email-icon"></i>
                            <a href="mailto:protectpdale@yahoo.com" target="_blank">protectpdale@yahoo.com</a>
                        </div>
                    </div>
                </div>
				
                <h2 class="contacts-section-title">Local Officials</h2>
                <div class="contact-list">
                    <div class="contact-list-item">
                        <div class="contact-name">Mayor John Egofske</div>
                        <div class="contact-email">
                            <i data-lucide="mail" class="contact-email-icon"></i>
                            <a href="mailto:jegofske@lemont.il.us">jegofske@lemont.il.us</a>
                        </div>
                    </div>
                    <div class="contact-list-item">
                        <div class="contact-name">Trustee Samuel Forzley</div>
                        <div class="contact-email">
                            <i data-lucide="mail" class="contact-email-icon"></i>
                            <a href="mailto:sforzley@lemont.il.us">sforzley@lemont.il.us</a>
                        </div>
                    </div>
                    <div class="contact-list-item">
                        <div class="contact-name">Trustee Janelle Kittridge</div>
                        <div class="contact-email">
                            <i data-lucide="mail" class="contact-email-icon"></i>
                            <a href="mailto:jkittridge@lemont.il.us">jkittridge@lemont.il.us</a>
                        </div>
                    </div>
                    <div class="contact-list-item">
                        <div class="contact-name">Trustee Ken McClafferty</div>
                        <div class="contact-email">
                            <i data-lucide="mail" class="contact-email-icon"></i>
                            <a href="mailto:kmcclafferty@lemont.il.us">kmcclafferty@lemont.il.us</a>
                        </div>
                    </div>
                    <div class="contact-list-item">
                        <div class="contact-name">Trustee Kevin Shaughnessy</div>
                        <div class="contact-email">
                            <i data-lucide="mail" class="contact-email-icon"></i>
                            <a href="mailto:kshaughnessy@lemont.il.us">kshaughnessy@lemont.il.us</a>
                        </div>
                    </div>
                    <div class="contact-list-item">
                        <div class="contact-name">Trustee Rick Sniegowski</div>
                        <div class="contact-email">
                            <i data-lucide="mail" class="contact-email-icon"></i>
                            <a href="mailto:rsniegowski@lemont.il.us">rsniegowski@lemont.il.us</a>
                        </div>
                    </div>
                    <div class="contact-list-item">
                        <div class="contact-name">Trustee Ron Stapleton</div>
                        <div class="contact-email">
                            <i data-lucide="mail" class="contact-email-icon"></i>
                            <a href="mailto:rstapleton@lemont.il.us">rstapleton@lemont.il.us</a>
                        </div>
                    </div>
                </div>

                <h2 class="contacts-section-title">News Stations</h2>
                <div class="contact-list">
                    <div class="contact-list-item">
                        <div class="contact-name">NBC Chicago</div>
                        <div class="contact-email">
                            <i data-lucide="external-link" class="contact-email-icon"></i>
                            <a href="https://www.nbcchicago.com/investigations/submit-tip/" target="_blank">Submit a Tip</a>
                        </div>
                    </div>
                    <div class="contact-list-item">
                        <div class="contact-name">Daily Herald</div>
                        <div class="contact-email">
                            <i data-lucide="mail" class="contact-email-icon"></i>
                            <a href="mailto:onlineeditors@dailyherald.com">onlineeditors@dailyherald.com</a>
                        </div>
                    </div>
                    <div class="contact-list-item">
                        <div class="contact-name">Fox Chicago</div>
                        <div class="contact-email">
                            <i data-lucide="mail" class="contact-email-icon"></i>
                            <a href="mailto:wfldassignmentdesk@fox.com">wfldassignmentdesk@fox.com</a>
                        </div>
                    </div>
                    <div class="contact-list-item">
                        <div class="contact-name">ABC 7</div>
                        <div class="contact-email">
                            <i data-lucide="mail" class="contact-email-icon"></i>
                            <a href="mailto:wls.desk@abc.com">wls.desk@abc.com</a>
                        </div>
                    </div>
                </div>

                <h2 class="contacts-section-title">Regulatory Agencies and Officials</h2>
                <div class="contact-list">
                    <div class="contact-list-item">
                        <div class="contact-name">Illinois Environmental Protection Agency</div>
                        <div class="contact-email">
                            <i data-lucide="external-link" class="contact-email-icon"></i>
                            <a href="https://epa.illinois.gov/pollution-complaint/submit-a-complaint.html" target="_blank">Submit a Complaint</a>
                        </div>
                    </div>
                    <div class="contact-list-item">
                        <div class="contact-name">DuPage County Department of Public Health</div>
                        <div class="contact-email">
                            <i data-lucide="mail" class="contact-email-icon"></i>
                            <a href="mailto:Adam.Forker@dupagehealth.org">Adam.Forker@dupagehealth.org</a>
                        </div>
                    </div>
                    <div class="contact-list-item">
                        <div class="contact-name">Representative Nicole La Ha</div>
                        <div class="contact-email">
                            <i data-lucide="external-link" class="contact-email-icon"></i>
                            <a href="https://replaha.com/contact/" target="_blank">RepLaha.com</a>
                        </div>
                    </div>
					
                </div>
            </div>
            <div class="template-reference">
                <details class="template-reference-card" style="cursor: pointer;">
                    <summary style="display: flex; align-items: center; gap: 0.75rem; list-style: none;">
                        <i data-lucide="file-text" class="template-reference-icon"></i>
                        <span class="template-reference-text" style="margin: 0;">Need a starter template? Click here to view a generic template.</span>
                        <i data-lucide="chevron-down" style="width: 20px; height: 20px; margin-left: auto; transition: transform 0.2s;"></i>
                    </summary>
                    <div style="margin-top: 1rem; padding-top: 1rem; border-top: 1px solid rgba(0,0,0,0.1);">
                        <p style="margin-bottom: 0.75rem; font-weight: 500;">Generic Template:</p>
                        <p style="line-height: 1.6; color: #374151;">
[Street Address]<br>
[City, State, ZIP Code]<br>
[Email Address]<br>
[Phone Number]<br>
[Date]<br>
<br>
<br>
Dear Friends and Supporters,<br>
<br>
I am reaching out on behalf of concerned residents of the Pleasantdale neighborhood in unincorporated Lemont regarding the proposed construction of a gas station on Lemont Road. This development poses significant risks to public safety, health, and the environment, and our community strongly opposes it.
Petitions and community support are already underway to halt this project. You can view the petitions and learn more at: https://protectpdale.com.<br>
<br>
<br>Key Concerns:
<br>
<br>1. Well Water Safety
<br>Many families near the proposed site rely on private wells for clean drinking water. Gas stations carry the risk of underground storage tank leaks, fuel spills, and contaminated runoff. Once groundwater is polluted, restoration is difficult, costly, and sometimes incomplete.
<br>
<br>2. Traffic & Pedestrian Safety
<br>The intersection of Lemont Road and 97th Street is already heavily congested, especially with traffic to Argonne National Laboratory and nearby commercial areas. A high-volume gas station would increase turning movements, delivery truck traffic, and congestion, creating heightened risks for drivers, pedestrians, and school buses.
<br>
<br>3. Public Health & Quality of Life
<br>Gas stations produce additional emissions, light, and noise. These impacts are more than minor inconveniences—they directly affect the health and well-being of families living nearby, particularly children and sensitive populations.
<br>
<br>4. Policing & Public Safety
<br>The proposed location is on the far edge of Lemont, away from the police department and main patrol routes. Gas stations are linked to increased service calls, including traffic accidents, theft, and loitering. A remote site would stretch local law enforcement resources and delay emergency response times.
<br>
<br>5. Environmental Protection
<br>The site is directly across from Waterfall Glen Forest Preserve, home to threatened and endangered species. Fuel spills, runoff, and habitat disruption could undermine decades of restoration work and public investment in protecting this unique preserve.
<br>
<br>How You Can Help:
<br>Please help our community advocate against the construction of this development. Your support, awareness, and voice are vital to protecting Pleasantdale’s homes, health, and environment.
<br>Thank you for your time and consideration.
<br>
<br>Sincerely,
<br>[Your Full Name]
<br>[Your Contact Information]
                        </p>
                    </div>
                </details>
                <style>
                    details[open] summary i[data-lucide="chevron-down"] {
                        transform: rotate(180deg);
                    }
                </style>
            </div>
			
        </div>
    </main>

    <footer class="footer">
        <div class="container">
            <p class="footer-text">Disclaimer: The content on this website is provided for informational purposes only and does not constitute professional advice. We make no warranties about the accuracy, completeness, or timeliness of the information. For advice tailored to your specific situation, please consult a qualified professional.</p>
        </div>
    </footer>


<?php get_footer(); ?>
