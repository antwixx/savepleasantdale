<?php
/* Template Name: home */
get_header();
?>

    <header class="header">
        <nav class="nav">
            <div class="nav-container">
                <a href="/home" class="nav-logo">
                    <span class="nav-logo-text">Protect Pleasantdale</span>
                </a>
                
                <button class="nav-toggle" id="navToggle">
                    <span></span>
                    <span></span>
                    <span></span>
                </button>
                
                <ul class="nav-menu" id="navMenu">
                    <li><a href="/home" class="nav-link active">Home</a></li>
                    <li><a href="/information" class="nav-link">Information</a></li>
                    <li><a href="/petitions" class="nav-link">Petitions</a></li>
                    <li><a href="/contacts" class="nav-link">Contacts</a></li>
                    <li><a href="/meetings" class="nav-link">Meetings</a></li>
                    <li><a href="/concerns" class="nav-link">Concerns</a></li>
                    <li><a href="/flyers" class="nav-link">Flyers</a></li>
                    <li><a href="/updates" class="btn btn-primary">Updates</a></li>
                </ul>
            </div>
        </nav>
    </header>

    <main>

        <section class="hero">
            <div class="hero-overlay"></div>
            <div class="hero-bg"></div>
            <div class="hero-content">
                <h1 class="hero-title">Protect Pleasantdale</h1>
                <h2 class="hero-subtitle">STOP THE PROPOSED TRUCK STOP FROM POLLUTING OUR NEIGHBORHOODS <br>& RUINING OUR WAY OF LIFE</h2>
                <p class="hero-description">
                    Join our community in protecting our neighborhoods from commercial rezoning that threatens our quality of life. Create awareness, contact officials, and educate!
                </p>
            <div class="hero-buttons">
                <a href="/petitions" class="btn btn-hero">
                    Sign Petition <i data-lucide="arrow-right"></i>
                </a>
                <a href="/information" class="btn btn-outline">
                    Learn More <i data-lucide="file-text"></i>
                </a>
                <a href="/concerns" class="btn btn-outline">
                    View Concerns <i data-lucide="alert-triangle"></i>
                </a>
            </div>
            </div>
        </section>


        <section class="alert-section">
            <div class="container">
                <div class="alert-card">
                    <div class="alert-content">
                        <i data-lucide="alert-triangle" class="alert-icon"></i>
                        <div class="alert-text">
                            <h3 class="alert-title">URGENT: Village Ordinance Passed</h3>
                            <p class="alert-description">
                                The <strong>Village of Lemont</strong> passed an ordinance on <strong>August 11th, 2025</strong> to annex four 
                                unincorporated properties on Lemont Road. These homes were purchased above market price and are part of the residential Pleasantdale neighborhood.
                            </p>
                            <p class="alert-description">
                                These properties are now <strong>incorporated</strong> into Lemont and fall under Lemont's jurisdiction. 
                                The next step would be for the owner to request Lemont to re-zone the properties from <strong>residential</strong> to <strong>commercial</strong>.
                            </p>
                        </div>
                    </div>
                </div>
            </div>
        </section>


			<section class="map-highlight">
				<div class="container">
					<div class="map-card">
					<h3 class="section-title">
						<i data-lucide="map" color="#2680d9" class="map-icon"></i> Community Impact Map
					</h3>
					<div class="map-image">
						<a href="<?php echo get_template_directory_uri(); ?>/assets/images/Pleasantdale-Road-Map.png" target="_blank"><img src="<?php echo get_template_directory_uri(); ?>/assets/images/Pleasantdale-Road-Map.png" alt="Pleasantdale subdivision map"></a>
					</div>
					<p class="map-caption">
						This map shows the Pleasantdale neighborhood, the proposed truck stop site, and the nearby Waterfall Glen Forest Preserve.
					</p>
					</div>
				</div>
			</section>



        <section class="main-content">
            <div class="container">
                <div class="content-grid">

                    <div class="content-card">
                        <h3 class="section-title"><i data-lucide="map-pin" class="lucide lucide-map-pin location-icon"></i> Proposed Location</h3>
                        <div class="map-container">
                            <iframe 
                                src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d10018.221111495996!2d-88.01336509159871!3d41.71113224083063!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x880e45295af3277f%3A0x1935b49e2e61fc3!2sLemont%20National%20Bank!5e0!3m2!1sen!2sus!4v1756159983799!5m2!1sen!2sus&maptype=hybrid" 
                                class="map-embed"
                                style="border:0;" 
                                allowfullscreen="" 
                                loading="lazy" 
                                referrerpolicy="no-referrer-when-downgrade"
                                title="Proposed truck stop location near Lemont National Bank">
                            </iframe>
                        </div>
                    </div>


                    <div class="content-info">
                        

                        
                        <div class="action-cards">
                            <a href="/petitions" class="action-card">
                                <div class="action-icon-wrapper">
                                    <i data-lucide="file-text" class="action-icon"></i>
                                </div>
                                <div class="action-content">
                                    <h4 class="action-title">Sign Petitions</h4>
                                    <p class="action-description">Add your voice to the community opposition</p>
                                </div>
                                <i data-lucide="arrow-right" class="action-arrow"></i>
                            </a>

                            <a href="/contacts" class="action-card">
                                <div class="action-icon-wrapper action-icon-secondary">
                                    <i data-lucide="users" class="action-icon"></i>
                                </div>
                                <div class="action-content">
                                    <h4 class="action-title">Contact Officials</h4>
                                    <p class="action-description">Reach out to village board members</p>
                                </div>
                                <i data-lucide="arrow-right" class="action-arrow"></i>
                            </a>
							<a href="https://www.zeffy.com/en-US/donation-form/donate-to-help-us-protect-the-neighborhood-and-boarding-lemont-area" target="_blank" class="action-card">
                                <div class="action-icon-wrapper action-icon-secondary">
                                    <i data-lucide="badge-dollar-sign" class="circle-dollar-sign-icon"></i>
                                </div>
                                <div class="action-content">
                                    <h4 class="action-title">Donate via Zeffy</h4>
                                    <p class="action-description">Donate via Zeffy to help the Pleasantdale. All major payments are supported.</p>
                                </div>
                                <i data-lucide="arrow-right" class="action-arrow"></i>
                            </a>
							<a href="<?php echo get_template_directory_uri(); ?>/assets/uploads/zelle.pdf" target="_blank" class="action-card">
                                <div class="action-icon-wrapper action-icon-secondary">
                                    <i data-lucide="circle-dollar-sign" class="circle-dollar-sign-icon"></i>
                                </div>
                                <div class="action-content">
                                    <h4 class="action-title">Donate via Zelle</h4>
                                    <p class="action-description">Donate via Zelle to help the Pleasantdale subdivision</p>
                                </div>
                                <i data-lucide="arrow-right" class="action-arrow"></i>
                            </a>
							
                        </div>
                    </div>
                </div>
            </div>
        </section>

        <!-- cta -->
        <section class="cta-section">
            <div class="container">
                <div class="cta-content">
                    <h3 class="cta-title">Our Pleasantdale Neighborhood</h3>
                    <p class="cta-description">
                        Pleasantdale is more than just a neighborhood—it’s a community built on history, family, and care for one another. Tucked away in unincorporated Lemont, Illinois, our neighborhood of approximately 320 single-family homes has grown and thrived since the first houses were built in 1957. Over the years, new families have joined longtime residents, creating a beautiful mix of generations—retirees, young couples, and children just starting school. Our neighborhood children attend Oakwood, River Valley, Old Quarry, Central, and Lemont High School, building connections that extend beyond our streets and into the wider community.<br><br>

Our tree-lined streets are filled with the sounds of kids riding bikes, neighbors greeting each other on walks, and families enjoying the quiet safety of a residential community. The mature trees and long-established homes are part of what makes Pleasantdale special, a place where families can slow down and feel at peace.<br><br>


That’s why we are deeply concerned about a possible proposal to place a large gas station and truck stop near our homes. A development of that scale does not belong in the middle of a residential area. We worry about increased traffic on our neighborhood streets, the safety of our children, and the groundwater, air, and noise pollution that would impact not only residents, but also the <a href="https://www.dupageforest.org/places-to-go/forest-preserves/waterfall-glen" target="_blank" style="color: white;">Waterfall Glen Forest Preserve</a> that sits directly across from the site. Our community was never designed to handle the hazards that come with constant truck traffic, underground fuel storage, and the dangers of a busy commercial site.<br><br>

The recent annexations and possible development united Pleasantdale together in opposition. We are strong because we look out for one another. We want our children to grow up safe, our families to thrive, and our community to remain the welcoming, peaceful place it has been for decades. This neighborhood is our home, and we stand together to protect it and the local environment for generations to come.<br><br>

Please join us in opposition to a possible large-scale truck stop and car wash on Lemont Road. We are engaged, we won’t be silent, and we are ALL paying attention to who will push to support this development.<br><br>
                    </p>
                    <div class="cta-buttons">
                        <a href="/meetings" class="btn btn-hero">Attend Meetings</a>
                        <a href="/flyers" class="btn btn-outline">Download Flyers</a>
                    </div>
                </div>
            </div>
        </section>
    </main>

    <footer class="footer">
        <div class="container">
            <p class="footer-text">Disclaimer: The content on this website is provided for informational purposes only and does not constitute professional advice. We make no warranties about the accuracy, completeness, or timeliness of the information. For advice tailored to your specific situation, please consult a qualified professional.</p>
        </div>
    </footer>


<?php get_footer(); ?>
