<?php
/* Template Name: information */
get_header();
?>

    <header class="header">
        <nav class="nav">
            <div class="nav-container">
                <a href="/home" class="nav-logo">
                    <span class="nav-logo-text">Protect Pleasantdale</span>
                </a>
                
                <button class="nav-toggle" id="navToggle">
                    <span></span>
                    <span></span>
                    <span></span>
                </button>
                
                <ul class="nav-menu" id="navMenu">
                    <li><a href="/home" class="nav-link">Home</a></li>
                    <li><a href="/information" class="nav-link active">Information</a></li>
                    <li><a href="/petitions" class="nav-link">Petitions</a></li>
                    <li><a href="/contacts" class="nav-link">Contacts</a></li>
                    <li><a href="/meetings" class="nav-link">Meetings</a></li>
                    <li><a href="/concerns" class="nav-link">Concerns</a></li>
                    <li><a href="/flyers" class="nav-link">Flyers</a></li>
					<li><a href="/updates" class="btn btn-primary">Updates</a></li>
                </ul>
            </div>
        </nav>
    </header>

    <main class="page-content">
        <div class="container">

            <div class="page-header">
                <h1 class="page-title">Information & Details</h1>
                <p class="page-description">
                    Understanding the truck stop proposal and its potential impact on our community.
                </p>
            </div>


            <div class="timeline-section">
                <h2 class="timeline-title">Development Timeline</h2>
                <div class="timeline">
                    <div class="timeline-item">
                        <div class="timeline-marker completed"></div>
                        <div class="timeline-content">
                            <div class="timeline-header">
                                <h3 class="timeline-event-title">
                                    Village Ordinance Passed
                                    <!---<span class="urgent-badge">URGENT</span>---!>
                                </h3>
                                <span class="timeline-date">August 11, 2025</span>
                            </div>
                            <p class="timeline-description">Village of Lemont passed ordinance to annex four unincorporated homes on Lemont Road. <br>The Official Annexation Ordinance can be viewed here: <a href="https://d2kbkoa27fdvtw.cloudfront.net/lemont/0da6172e728eb5029f569bf590db6f0e0.pdf" target="_blank">Lemont Annexation Ordinance</a></p>
                        </div>
                    </div>

                    <div class="timeline-item">
                        <div class="timeline-marker current"></div>
                        <div class="timeline-content">
                            <div class="timeline-header">
                                <h3 class="timeline-event-title">Properties Incorporated</h3>
                                <span class="timeline-date">Current Status</span>
                            </div>
                            <p class="timeline-description">These four properties now fall under Lemont's jurisdiction as part of the Pleasantdale neighborhood</p>
                        </div>
                    </div>

                    <div class="timeline-item">
                        <div class="timeline-marker pending"></div>
                        <div class="timeline-content">
                            <div class="timeline-header">
                                <h3 class="timeline-event-title">
                                    Potential Rezoning Request
                                    <span class="urgent-badge">URGENT</span>
                                </h3>
                                <span class="timeline-date">Next Step</span>
                            </div>
                            <p class="timeline-description">Property owner may request rezoning from residential to commercial for gas station development</p>
                        </div>
                    </div>
                </div>
            </div>

            <div class="impact-section">
                <h2 class="research-title">Impact Overview</h2>
                
                <div class="impact-cards-grid">
                    <div class="impact-card">
                        <div class="impact-card-header">
                            <div class="impact-icon-wrapper">
                                <i data-lucide="truck" class="impact-icon"></i>
                            </div>
                            <h3 class="impact-card-title">Traffic Impact</h3>
                        </div>
                        <p class="impact-card-subtitle">Many large commercial vehicles daily through residential streets</p>
                        <ul class="impact-bullet-list">
                            <li>24/7 truck traffic on Lemont Road</li>
                            <li>Damage to residential road infrastructure</li>
                            <li>Increased congestion and safety risks</li>
                            <li>Noise from diesel engines and air brakes</li>
                        </ul>
						<br><a href="<?php echo get_template_directory_uri(); ?>/assets/uploads/Traffic.pdf" target="_blank" class="btn btn-small"> Download PDF with Citations </a>
                    </div>

                    <div class="impact-card">
                        <div class="impact-card-header">
                            <div class="impact-icon-wrapper">
                                <i data-lucide="droplet" class="impact-icon"></i>
                            </div>
                            <h3 class="impact-card-title">Wells & Septic</h3>
                        </div>
                        <p class="impact-card-subtitle">Drinking water and septic systems at risk of contamination</p>
                        <ul class="impact-bullet-list">
                            <li>Contamination risks to private wells</li>
                            <li>No routine testing for homeowner water safety</li>
                            <li>Septic systems disrupted by paving and runoff</li>
                            <li>Dual threats from fuel leaks and septic discharge</li>
                        </ul>
						<br><a href="<?php echo get_template_directory_uri(); ?>/assets/uploads/Wells.pdf" target="_blank" class="btn btn-small"> Download PDF with Citations </a>
                    </div>

                    <div class="impact-card">
                        <div class="impact-card-header">
                            <div class="impact-icon-wrapper">
                                <i data-lucide="alert-triangle" class="impact-icon"></i>
                            </div>
                            <h3 class="impact-card-title">Environmental Concerns</h3>
                        </div>
                        <p class="impact-card-subtitle">Air and noise pollution affecting community health</p>
                        <ul class="impact-bullet-list">
                            <li>Diesel emissions and air quality degradation</li>
                            <li>Potential groundwater contamination</li>
                            <li>24/7 noise pollution from trucks and operations</li>
                            <li>Light pollution from 24-hour operations</li>
                        </ul>
						<br><a href="<?php echo get_template_directory_uri(); ?>/assets/uploads/Environment.pdf" target="_blank" class="btn btn-small"> Download PDF with Citations </a>
                    </div>

                    <div class="impact-card">
                        <div class="impact-card-header">
                            <div class="impact-icon-wrapper">
                                <i data-lucide="shield-alert" class="impact-icon"></i>
                            </div>
                            <h3 class="impact-card-title">Health & Safety</h3>
                        </div>
                        <p class="impact-card-subtitle">Increased crime risk and emergency response concerns</p>
                        <ul class="impact-bullet-list">
                            <li>Higher crime rates at gas stations and truck stops</li>
                            <li>Exposure to harmful fuel vapors and emissions</li>
                            <li>Increased emergency response calls</li>
                            <li>Safety risks from heavy truck traffic</li>
                        </ul>
						<br><a href="<?php echo get_template_directory_uri(); ?>/assets/uploads/Health-Safety.pdf" target="_blank" class="btn btn-small"> Download PDF with Citations </a>
                    </div>
                </div>
            </div><br><br>


            <div class="location-grid">
                <div class="location-card">
                    <div class="location-header">
                        <i data-lucide="map-pin" class="location-icon"></i>
                        <h2 class="location-title">Location Details</h2>
                    </div>
                    <div class="location-details">
                        <div class="location-item">
                            <h4 class="location-item-title">Affected Area</h4>
                            <p class="location-item-description">
                                Four unincorporated properties on Lemont Road next to Lemont National Bank, part of the residential Pleasantdale neighborhood
                            </p>
                        </div>
                        <div class="location-item">
                            <h4 class="location-item-title">Current Zoning</h4>
                            <p class="location-item-description">
                                Currently zoned as <strong>residential</strong>, these properties would need to be rezoned to <strong>commercial</strong>
                            </p>
                        </div>
                        <div class="location-item">
                            <h4 class="location-item-title">Jurisdiction</h4>
                            <p class="location-item-description">
                                Now under Village of Lemont authority following August 11th annexation ordinance
                            </p>
                        </div>
                    </div>
                </div>

                <div class="action-guide-card">
                    <h2 class="action-guide-title">What You Can Do</h2>
                    <div class="action-guide-items">
                        <div class="action-guide-item">
                            <h4 class="action-guide-item-title">Sign Petitions</h4>
                            <p class="action-guide-item-description">
                                Add your voice to community petitions opposing the development
                            </p>
                        </div>
                        <div class="action-guide-item">
                            <h4 class="action-guide-item-title">Contact Officials</h4>
                            <p class="action-guide-item-description">
                                Reach out to village board members and express your concerns
                            </p>
                        </div>
                        <div class="action-guide-item">
                            <h4 class="action-guide-item-title">Attend Meetings</h4>
                            <p class="action-guide-item-description">
                                Participate in village board meetings and public hearings
                            </p>
                        </div>
                        <div class="action-guide-item">
                            <h4 class="action-guide-item-title">Spread Awareness</h4>
                            <p class="action-guide-item-description">
                                Share information with neighbors and on social media
                            </p>
                        </div>
                    </div>
                </div>
            </div>


            <div class="final-cta">
                <h2 class="final-cta-title">Time is Critical</h2>
                <p class="final-cta-description">
                    Once a rezoning request is submitted, our window to oppose it becomes much smaller. 
                    Act now to protect our neighborhood's residential character.
                </p>
                <div class="final-cta-buttons">
                    <a href="/petitions" class="btn btn-outline">Sign Petitions Now</a>
                    <a href="/contacts" class="btn btn-outline">Contact Officials</a>
                </div>
            </div>
        </div>
    </main>

    <footer class="footer">
        <div class="container">
            <p class="footer-text">Disclaimer: The content on this website is provided for informational purposes only and does not constitute professional advice. We make no warranties about the accuracy, completeness, or timeliness of the information. For advice tailored to your specific situation, please consult a qualified professional.</p>
        </div>
    </footer>


<?php get_footer(); ?>
