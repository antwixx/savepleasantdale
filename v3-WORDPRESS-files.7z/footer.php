
<!-- Theme footer starts here -->
<footer id="site-footer">

</footer>

<?php wp_footer(); ?>
</body>
</html>
