<?php
/* Template Name: petitions */
get_header();
?>

    <header class="header">
        <nav class="nav">
            <div class="nav-container">
                <a href="/home" class="nav-logo">
                    <span class="nav-logo-text">Protect Pleasantdale</span>
                </a>
                
                <button class="nav-toggle" id="navToggle">
                    <span></span>
                    <span></span>
                    <span></span>
                </button>
                
                <ul class="nav-menu" id="navMenu">
                    <li><a href="/home" class="nav-link">Home</a></li>
                    <li><a href="/information" class="nav-link">Information</a></li>
                    <li><a href="/petitions" class="nav-link active">Petitions</a></li>
                    <li><a href="/contacts" class="nav-link">Contacts</a></li>
                    <li><a href="/meetings" class="nav-link">Meetings</a></li>
                    <li><a href="/concerns" class="nav-link">Concerns</a></li>
                    <li><a href="/flyers" class="nav-link">Flyers</a></li>
					<li><a href="/updates" class="btn btn-primary">Updates</a></li>
                </ul>
            </div>
        </nav>
    </header>

    <main class="page-content">
        <div class="container">

            <div class="page-header">
                <h1 class="page-title">Community Petitions</h1>
                <p class="page-description">
                    Add your voice to our community petitions. Every signature strengthens our collective opposition to the proposed truck stop development.
                </p>
            </div>

			<div class="template-reference">
                <div class="template-reference-card">
                    <i data-lucide="file-text" class="template-reference-icon"></i>
                    <p class="template-reference-text">
                        Any donation made via the Change.org website is kept by change.org to fund their operations and will not reach the stated petition starter nor anyone associated with this community action. If you would like to donate, please <a href="https://www.zeffy.com/en-US/donation-form/donate-to-help-us-protect-the-neighborhood-and-boarding-lemont-area" target="_blank" class="template-link">Visit Zeffy</a> for details.
                    </p>
                </div>
            </div>
			

            <div class="petition-list">
                <div class="petition-card">
                    <div class="petition-content">
                        <div class="petition-header">
                            <div class="petition-icon-wrapper urgent">
                                <i data-lucide="file-text" class="petition-icon"></i>
                            </div>
                            <div class="petition-title-section">
                                <div class="petition-title-row">
                                    <h3 class="petition-title">Stop Gas N Wash Lemont Rd</h3>
                                    <span class="urgent-badge">URGENT</span>
                                </div>
                                <p class="petition-description">Primary petition opposing the commercial rezoning of residential properties on Lemont Road for truck stop development.</p>
                            </div>
                        </div>


                        <div class="petition-progress">
                            <div class="progress-info">
                                <div class="progress-stats">
                                    <i data-lucide="users" class="progress-icon"></i>
                                    <span class="progress-text">1,953 of 2,000 signatures</span>
                                </div>
                                <span class="progress-percentage">97%</span>
                            </div>
                            <div class="progress-bar">
                                <div class="progress-fill" style="width: 97%"></div>
                            </div>
                        </div>
                    </div>

                    <div class="petition-action">
                        <a href="https://www.change.org/p/stop-gas-n-wash-lemont-road" target="_blank" class="btn btn-hero">Sign Petition </a>
                    </div>
                </div>

                <div class="petition-card">
                    <div class="petition-content">
                        <div class="petition-header">
                            <div class="petition-icon-wrapper">
                                <i data-lucide="file-text" class="petition-icon"></i>
                            </div>
                            <div class="petition-title-section">
                                <div class="petition-title-row">
                                    <h3 class="petition-title">Stop the construction of a Gas Station on Lemont Rd</h3>
                                </div>
                                <p class="petition-description">Petition highlighting environmental and safety concerns related to the proposed truck stop facility.</p>
                            </div>
                        </div>


                        <div class="petition-progress">
                            <div class="progress-info">
                                <div class="progress-stats">
                                    <i data-lucide="users" class="progress-icon"></i>
                                    <span class="progress-text">453 of 500 signatures</span>
                                </div>
                                <span class="progress-percentage">91%</span>
                            </div>
                            <div class="progress-bar">
                                <div class="progress-fill" style="width: 91%"></div>
                            </div>
                        </div>
                    </div>

                    <div class="petition-action">

						<a href="https://www.change.org/p/stop-the-construction-of-a-gas-station-on-lemont-rd" target="_blank" class="btn btn-hero">Sign Petition </a>
                    </div>
                </div>
            </div>


            <div class="info-grid">
                <div class="info-card">
                    <div class="info-header">
                        <i data-lucide="check-circle" class="info-icon"></i>
                        <h2 class="info-title">Why Your Signature Matters</h2>
                    </div>
                    <ul class="info-list">
                        <li class="info-item">
                            <div class="info-bullet"></div>
                            <span>Demonstrates community unity and opposition</span>
                        </li>
                        <li class="info-item">
                            <div class="info-bullet"></div>
                            <span>Provides concrete evidence for official presentations</span>
                        </li>
                        <li class="info-item">
                            <div class="info-bullet"></div>
                            <span>Strengthens our position in zoning hearings</span>
                        </li>
                        <li class="info-item">
                            <div class="info-bullet"></div>
                            <span>Shows officials the scale of community concern</span>
                        </li>
                    </ul>
                </div>

                <div class="help-card">
                    <h2 class="help-title">How to Help Spread the Word</h2>
                    <div class="help-items">
                        <div class="help-item">
                            <h4 class="help-item-title">Share with Neighbors</h4>
                            <p class="help-item-description">
                                Talk to your neighbors and encourage them to sign the petitions
                            </p>
                        </div>
                        <div class="help-item">
                            <h4 class="help-item-title">Social Media</h4>
                            <p class="help-item-description">
                                Share petition links on community Facebook groups and social media
                            </p>
                        </div>
                        <div class="help-item">
                            <h4 class="help-item-title">Print Flyers</h4>
                            <p class="help-item-description">
                                Download and distribute flyers in your neighborhood
                            </p>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </main>

    <footer class="footer">
        <div class="container">
            <p class="footer-text">Disclaimer: The content on this website is provided for informational purposes only and does not constitute professional advice. We make no warranties about the accuracy, completeness, or timeliness of the information. For advice tailored to your specific situation, please consult a qualified professional.</p>
        </div>
    </footer>


<?php get_footer(); ?>
