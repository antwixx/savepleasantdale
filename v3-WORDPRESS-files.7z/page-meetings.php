<?php
/* Template Name: meetings */
get_header();
?>

    <header class="header">
        <nav class="nav">
            <div class="nav-container">
                <a href="/home" class="nav-logo">
                    <span class="nav-logo-text">Protect Pleasantdale</span>
                </a>
                
                <button class="nav-toggle" id="navToggle">
                    <span></span>
                    <span></span>
                    <span></span>
                </button>
                
                <ul class="nav-menu" id="navMenu">
                    <li><a href="/home" class="nav-link">Home</a></li>
                    <li><a href="/information" class="nav-link">Information</a></li>
                    <li><a href="/petitions" class="nav-link">Petitions</a></li>
                    <li><a href="/contacts" class="nav-link">Contacts</a></li>
                    <li><a href="/meetings" class="nav-link active">Meetings</a></li>
                    <li><a href="/concerns" class="nav-link">Concerns</a></li>
                    <li><a href="/flyers" class="nav-link">Flyers</a></li>
					<li><a href="/updates" class="btn btn-primary">Updates</a></li>
                </ul>
            </div>
        </nav>
    </header>

    <main class="page-content">
        <div class="container">

            <div class="page-header">
                <h1 class="page-title">Upcoming Meetings</h1>
                <p class="page-description">
                    Stay informed about village board meetings and events. Your attendance shows strong community opposition to the proposed truck stop.
                </p>
            </div>


			<div class="meeting-alert">
						<div class="alert-content">
                    <i data-lucide="alert-triangle" class="alert-icon"></i>
                    <div class="alert-text">
                        <h3 class="alert-title">Meeting Alerts</h3>
                        <p class="alert-description">
                            Please confirm all Village of Lemont meetings by visiting their calendar at: <a href="https://www.lemont.il.us/government/village-board-commission-meetings" target="_blank">Village of Lemont Board Calendar</a><br><br>
							Livestreams of the Village of Lemont Board Meetings can be found here: <a href="https://www.youtube.com/@villageoflemonttv/streams" target="_blank"> Village of Lemont Youtube Channel </a><br><br>
							Please confirm all Village of Woodridge meetings by visiting their calendar at: <a href="https://vilwoodridge.community.highbond.com/Portal/MeetingSchedule.aspx" target="_blank">Village of Woodridge Board Calendar</a><br><br>
							Livestreams of the Village of Woodridge Board Meetings can be found here: <a href="https://www.youtube.com/@woodridgeil/streams" target="_blank"> Village of Woodridge Youtube Channel </a><br>
							
                        </p>
                    </div>
                </div>
            </div>
			<br><br>
			

            <div class="meetings-list">
				<div class="meeting-card">
                    <div class="meeting-header">
                        <div class="meeting-icon-wrapper">
                            <i data-lucide="calendar" class="meeting-icon"></i>
                        </div>
                        <div class="meeting-title-section">
                            <h3 class="meeting-title">[Woodridge] Village Board Meeting</h3>
                            <p class="meeting-type">Regular Meeting</p>
                        </div>
                    </div>

                    <div class="meeting-details">
                        <div class="meeting-detail">
                            <i data-lucide="calendar" class="detail-icon"></i>
                            <span>Thursday October 16th, 2025</span>
                        </div>
                        <div class="meeting-detail">
                            <i data-lucide="clock" class="detail-icon"></i>
                            <span>7:00 PM</span>
                        </div>
                        <div class="meeting-detail">
                            <i data-lucide="map-pin" class="detail-icon"></i>
                            <span>5 Plaza Drive Woodridge, Illinois</span>
                        </div>
                    </div>

                    <div class="meeting-description">
                        <p>Regular Village Board meeting where potential rezoning discussions may occur. Community attendance is essential to show opposition.</p>
                    </div>

                </div>
				
				
                <div class="meeting-card">
                    <div class="meeting-header">
                        <div class="meeting-icon-wrapper">
                            <i data-lucide="calendar" class="meeting-icon"></i>
                        </div>
                        <div class="meeting-title-section">
                            <h3 class="meeting-title">[Lemont] Committee of the Whole Meeting</h3>
                            <p class="meeting-type">Regular Meeting</p>
                        </div>
                    </div>

                    <div class="meeting-details">
                        <div class="meeting-detail">
                            <i data-lucide="calendar" class="detail-icon"></i>
                            <span>Monday October 20th, 2025</span>
                        </div>
                        <div class="meeting-detail">
                            <i data-lucide="clock" class="detail-icon"></i>
                            <span>6:30 PM</span>
                        </div>
                        <div class="meeting-detail">
                            <i data-lucide="map-pin" class="detail-icon"></i>
                            <span>418 Main Street Lemont, Illinois</span>
                        </div>
                    </div>

                    <div class="meeting-description">
                        <p>Village Board meets together as a single committee to <strong>discuss issues freely</strong> without the urgency of a final vote.</p>
                    </div>

                </div>
				
				<div class="meeting-card">
                    <div class="meeting-header">
                        <div class="meeting-icon-wrapper">
                            <i data-lucide="calendar" class="meeting-icon"></i>
                        </div>
                        <div class="meeting-title-section">
                            <h3 class="meeting-title">[Woodridge] Plan Commission Meeting</h3>
                            <p class="meeting-type">Plan Commission Meeting</p>
                        </div>
                    </div>

                    <div class="meeting-details">
                        <div class="meeting-detail">
                            <i data-lucide="calendar" class="detail-icon"></i>
                            <span>Monday October 20th, 2025</span>
                        </div>
                        <div class="meeting-detail">
                            <i data-lucide="clock" class="detail-icon"></i>
                            <span>7:00 PM</span>
                        </div>
                        <div class="meeting-detail">
                            <i data-lucide="map-pin" class="detail-icon"></i>
                            <span>5 Plaza Drive Woodridge, Illinois</span>
                        </div>
                    </div>

                    <div class="meeting-description">
                        <p>Plan Commission meetings involve reviewing and recommending decisions on development proposals, zoning issues, and amendments to the Comprehensive Plan to the Village Board.</p>
                    </div>

                </div>
				
                <div class="meeting-card">
                    <div class="meeting-header">
                        <div class="meeting-icon-wrapper">
                            <i data-lucide="calendar" class="meeting-icon"></i>
                        </div>
                        <div class="meeting-title-section">
                            <h3 class="meeting-title">[Lemont] Lemont Environmental Advisory Commission</h3>
                            <p class="meeting-type">Environmental Advisory Commission</p>
                        </div>
                    </div>

                    <div class="meeting-details">
                        <div class="meeting-detail">
                            <i data-lucide="calendar" class="detail-icon"></i>
                            <span>Thursday October 23rd, 2025</span>
                        </div>
                        <div class="meeting-detail">
                            <i data-lucide="clock" class="detail-icon"></i>
                            <span>7:00 PM</span>
                        </div>
                        <div class="meeting-detail">
                            <i data-lucide="map-pin" class="detail-icon"></i>
                            <span>418 Main Street Lemont, Illinois</span>
                        </div>
                    </div>

                    <div class="meeting-description">
                        <p>Environmental Advisory Commission meetings are official gatherings where commissioners discuss environmental issues, advise the Village Board, and plan programs</p>
                    </div>
				</div>
					

                <div class="meeting-card">
                    <div class="meeting-header">
                        <div class="meeting-icon-wrapper">
                            <i data-lucide="calendar" class="meeting-icon"></i>
                        </div>
                        <div class="meeting-title-section">
                            <h3 class="meeting-title">[Lemont] Village Board Meeting</h3>
                            <p class="meeting-type">Regular Meeting</p>
                        </div>
                    </div>

                    <div class="meeting-details">
                        <div class="meeting-detail">
                            <i data-lucide="calendar" class="detail-icon"></i>
                            <span>Monday October 27th, 2025</span>
                        </div>
                        <div class="meeting-detail">
                            <i data-lucide="clock" class="detail-icon"></i>
                            <span>6:30 PM</span>
                        </div>
                        <div class="meeting-detail">
                            <i data-lucide="map-pin" class="detail-icon"></i>
                            <span>418 Main Street Lemont, Illinois</span>
                        </div>
                    </div>

                    <div class="meeting-description">
                        <p>Regular Village Board meeting where potential rezoning discussions may occur. Community attendance is essential to show opposition.</p>
                    </div>
				</div>
				
								<div class="meeting-card">
                    <div class="meeting-header">
                        <div class="meeting-icon-wrapper">
                            <i data-lucide="calendar" class="meeting-icon"></i>
                        </div>
                        <div class="meeting-title-section">
                            <h3 class="meeting-title">[Woodridge] Plan Commission Meeting</h3>
                            <p class="meeting-type">Plan Commission Meeting</p>
                        </div>
                    </div>

                    <div class="meeting-details">
                        <div class="meeting-detail">
                            <i data-lucide="calendar" class="detail-icon"></i>
                            <span>Monday November 3rd, 2025</span>
                        </div>
                        <div class="meeting-detail">
                            <i data-lucide="clock" class="detail-icon"></i>
                            <span>7:00 PM</span>
                        </div>
                        <div class="meeting-detail">
                            <i data-lucide="map-pin" class="detail-icon"></i>
                            <span>5 Plaza Drive Woodridge, Illinois</span>
                        </div>
                    </div>

                    <div class="meeting-description">
                        <p>Plan Commission meetings involve reviewing and recommending decisions on development proposals, zoning issues, and amendments to the Comprehensive Plan to the Village Board.</p>
                    </div>

                </div>
				
				
								<div class="meeting-card">
                    <div class="meeting-header">
                        <div class="meeting-icon-wrapper">
                            <i data-lucide="calendar" class="meeting-icon"></i>
                        </div>
                        <div class="meeting-title-section">
                            <h3 class="meeting-title">[Woodridge] Village Board Meeting</h3>
                            <p class="meeting-type">Regular Meeting</p>
                        </div>
                    </div>

                    <div class="meeting-details">
                        <div class="meeting-detail">
                            <i data-lucide="calendar" class="detail-icon"></i>
                            <span>Thursday November 6th, 2025</span>
                        </div>
                        <div class="meeting-detail">
                            <i data-lucide="clock" class="detail-icon"></i>
                            <span>7:00 PM</span>
                        </div>
                        <div class="meeting-detail">
                            <i data-lucide="map-pin" class="detail-icon"></i>
                            <span>5 Plaza Drive Woodridge, Illinois</span>
                        </div>
                    </div>

                    <div class="meeting-description">
                        <p>Regular Village Board meeting where potential rezoning discussions may occur. Community attendance is essential to show opposition.</p>
                    </div>
                </div>
				
				
            </div>
			

            <div class="location-grid">
                <div class="location-card">
                    <div class="location-header">
                        <i data-lucide="info" class="guide-icon"></i>
                        <h2 class="location-title">How to Participate in Meetings</h2>
                    </div>
                    <div class="location-details">
                        <div class="location-item">
                            <h4 class="location-item-title">Arrive Early & Bring Others</h4>
                            <p class="location-item-description">
                                Get there 15-20 minutes before the meeting starts to secure seating and encourage neighbors to attend with you
                            </p>
                        </div>
                        <div class="location-item">
                            <h4 class="location-item-title">Sign Up for Public Comment</h4>
                            <p class="location-item-description">
                                Most meetings have a public comment period - sign up when you arrive
                            </p>
                        </div>
                        <div class="location-item">
                            <h4 class="location-item-title">Be Respectful but Firm</h4>
                            <p class="location-item-description">
                                Present your feedback and concerns professionally and stick to the facts - do not delve into rumor. 
                            </p>
                        </div>
                    </div>
                </div>

                <div class="resources-card">
                    <h2 class="resources-title">Meeting Tips</h2>
                    <div class="resource-items">
                        <div class="resource-item">
                            <i data-lucide="file-text" class="resource-icon"></i>
                            <div class="resource-content">
                                <h4 class="resource-title">Speaking Points Preparation</h4>
                                <p class="resource-description">Gather resources to provide key points to cover during public comment periods</p>
                            </div>
                        </div>
                        <div class="resource-item">
                            <i data-lucide="calendar" class="resource-icon"></i>
                            <div class="resource-content">
                                <h4 class="resource-title">Meeting Calendar</h4>
                                <p class="resource-description">Check this page periodically to stay updated on all village meetings</p>

                            </div>
                        </div>
                        <div class="resource-item">
                            <i data-lucide="users" class="resource-icon"></i>
                            <div class="resource-content">
                                <h4 class="resource-title">Neighbor Coordination</h4>
                                <p class="resource-description">Connect and share with neighbors to attend meetings together</p>

                            </div>
                        </div>
                    </div>
                </div>
            </div>

 
        </div>
    </main>

    <footer class="footer">
        <div class="container">
            <p class="footer-text">Disclaimer: The content on this website is provided for informational purposes only and does not constitute professional advice. We make no warranties about the accuracy, completeness, or timeliness of the information. For advice tailored to your specific situation, please consult a qualified professional.</p>
        </div>
    </footer>


<?php get_footer(); ?>
